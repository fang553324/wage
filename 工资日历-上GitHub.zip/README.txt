工资日历 · 上传用文件

里面就一个 index.html，这是应用本体（单文件，CSS/JS/图标全内联）。
上传到 GitHub 仓库根目录后，文件名必须保持 index.html，否则打开会 404。
